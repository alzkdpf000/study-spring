package com.example.threetier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThreetierApplication {

    public static void main(String[] args) {
        SpringApplication.run(ThreetierApplication.class, args);
    }

}
