package com.example.controller.common.exception.test;

public class TestException extends RuntimeException{

    public TestException(){}

    public TestException(String message){
        super(message);
    }
}
